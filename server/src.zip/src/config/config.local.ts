// export const development = {
//   watchDirs: [
//     'app',
//     'lib',
//     'service',
//     'config',
//     'app.ts',
//     'agent.ts',
//     'interface.ts',
//   ],
//   overrideDefault: true,
// };
import { EggAppConfig, PowerPartial } from 'egg';

export default () => {
  const config: PowerPartial<EggAppConfig> = {};
  // business domain
  config.apiDomain = {
  };
  config.mysql = {
    client: {
      // host
      host: '47.104.172.100',
      // pot
      port: '3306',
      // userName
      user: 'root',
      // password
      password: 'jojgameTest2021.',
      // database name
      database: 'poker',
    },
    app: true,
    agent: false,
  };
  return config;
};
