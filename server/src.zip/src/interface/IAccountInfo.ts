export interface IAccountInfo {
  userAccount: string;
  password: string;
  nickName?: string;
}
