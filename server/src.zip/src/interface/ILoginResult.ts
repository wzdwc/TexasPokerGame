export interface ILoginResult {
  token: string;
}
