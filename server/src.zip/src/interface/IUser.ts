export interface IUser {
  nickName: string;
  account: string;
  password?: string;
  id?: string;
}
