
export interface IRequestBody {
  head: any;
  body: any;
}
