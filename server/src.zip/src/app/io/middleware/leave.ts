import { Context } from 'midway';

export default function leave(): any {
  return async (ctx: Context, next: () => Promise<any>) => {
  };
}
