import { Controller } from 'egg';
import { IGameRoom, IRoomInfo } from '../interface/IGameRoom';
import { IPlayer } from '../app/core/Player';

export default class BaseSocketController extends Controller {

  public app = this.ctx.app as any;
  public nsp = this.app.io.of('/socket');
  public gameRooms = this.nsp.gameRooms;
  public socket = this.ctx.socket as any;
  public query = this.socket.handshake.query;
  public roomNumber = this.query.room;
  public jwt: any = this.app.jwt;
  public message = this.ctx.args[0] || {};

  async getUserInfo() {
    const { token } = this.query;
    const user: IPlayer = this.jwt.verify(token) && this.jwt.verify(token).user;
    return user;
  }

  async getRoomInfo(): Promise<IRoomInfo> {
    const { room } = this.query;
    const roomInfo = this.gameRooms.find((gr: IGameRoom) => gr.number === room);
    return roomInfo.roomInfo;
  }

  async updateGameInfo() {
    const roomInfo = await this.getRoomInfo();
    console.log(roomInfo, 'roomInfo ===============================');
    this.nsp.adapter.clients([ this.roomNumber ], (err: any, clients: any) => {
      if (roomInfo.game && roomInfo.game.status < 6) {
        roomInfo.players.forEach(p => {
          const currPlayer = roomInfo.game &&
            roomInfo.game.allPlayer.find(player => player.userId === p.userId);
          p.counter = currPlayer && currPlayer.counter || 0;
        });
        console.log(roomInfo.players, 'roomInfo.players ===============================');
        const gameInfo = {
          players: roomInfo.players.map(p => {
            const currPlayer = roomInfo.game?.allPlayer.find(player => player.userId === p.userId);
            return Object.assign({}, {
              counter: currPlayer?.counter || 0,
              actionSize: currPlayer?.actionSize || 0,
              actionCommand: currPlayer?.actionCommand || '',
              nickName: p.nickName,
              type: currPlayer?.type || '',
              userId: p.userId,
              buyIn: p.buyIn || 0,
            }, {});
          }),
          pot: roomInfo.game.pot,
          prevSize: roomInfo.game.prevSize,
          currPlayer: {
            userId: roomInfo.game.currPlayer.node.userId,
          },
        };
        // 广播信息
        this.nsp.to(this.roomNumber).emit('online', {
          clients,
          action: 'gameInfo',
          target: 'participator',
          data: gameInfo,
        });
      }
    });
  }
}
