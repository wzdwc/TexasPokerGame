export interface ICommandRecord {
  roomId: string;
  gameId: string;
  userId: string;
  type: string;
  command: string;
}
