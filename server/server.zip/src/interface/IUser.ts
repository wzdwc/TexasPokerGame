export interface IUser {
  nick_name: string;
  account: string;
  password?: string;
  id?: string;
}
