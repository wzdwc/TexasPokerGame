export interface ITickMsg {
  type: string;
  message: string;
}
